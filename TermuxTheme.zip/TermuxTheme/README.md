# TermuxTheme
TEMA BONITO PARÁ TU TERMUX
# INSTRUCCIONES 

git clone https://github.com/Arturo254/Termux-Theme

cd Termux-Theme

bash setup

bash TermuxTheme.sh
