# TermuxTheme
PERSONALIZA EL BANNER DE TU TERMUX CON ESTA INCREÍBLE HERRAMIENTA
# INSTRUCCIONES
git clone https://github.com/Arturo254/TermuxTheme

cd Termux-Theme

unzip TermuxTheme.zip

chmod 777 *

chmod +x *

bash setup
 
bash TermuxTheme.sh 

